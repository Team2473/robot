#include "sdkcommon.h"
#include "thread.h"
#include "locker.h"
#include "event.h"
#include "scanner_driver_serial.h"

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

ScannerDriver * ScannerDriver::CreateDriver()
{
	return new ScannerDriverSerial();
}

void ScannerDriver::DestroyDriver(ScannerDriver * drv)
{
	delete drv;
}

//Serial Driver

ScannerDriverSerial::ScannerDriverSerial()
	: _isConnected(false)
{
	_my_serial = NULL;
}

ScannerDriverSerial::~ScannerDriverSerial()
{
	disconnect();
}

status ScannerDriverSerial::connect(const char* port, uint32_t baud, uint32_t timeout)
{

	if (isConnected()) return S_OK;

	_my_serial = new serial::Serial(port, baud, serial::Timeout::simpleTimeout(timeout));

	if(_my_serial->isOpen())
	{
		_my_serial->flush();

	  _isConnected = true;

	  return S_OK;
	}
	else
	{
		return S_FAIL;
	}

}

void ScannerDriverSerial::disconnect()
{
	if (!_isConnected) return ;

	stop();

	_my_serial->close();
}

bool ScannerDriverSerial::isConnected()
{
	return _isConnected;
}

status ScannerDriverSerial::stop()
{
	_disableDataGrabbing();
	uint8_t cmd[] = {'S', 'X'};
	status ans = _sendCommand(cmd);
	return ans;
}

status ScannerDriverSerial::startScan(uint32_t timeout)
{
   status ans;
   if (!isConnected()) return S_OK;
   if (_isScanning) return S_OK;

   stop();

   usleep(5000);

   _my_serial->flushInput();

   uint8_t cmd[] = {'S', 'D'};

	if(_sendCommand(cmd))
	{
		return S_FAIL;
	}

	scanner_ans_header_t response_header;
	if(_waitResponseHeader(&response_header, timeout))
	{
		return S_FAIL;
	}

	if(response_header.cmdByte1 != SCANNER_ANS_TYPE_MEASUREMENT)
	{
		return S_FAIL;
	}

	uint8_t tempSum = ((response_header.cmdStatusByte1 + response_header.cmdStatusByte2) & 0x3F) + 0x30;

	if(response_header.cmdSum != tempSum)
	{
		return S_FAIL;
	}

	_isScanning = true;
	_cachethread = CLASS_THREAD(ScannerDriverSerial, _cacheScanData);

   return S_OK;
}

status ScannerDriverSerial::_cacheScanData()
{
    scanner_response_measurement_node_t      local_buf[128];
    size_t                                   count = 128;
    scanner_response_measurement_node_t      local_scan[MAX_SCAN_NODES];
    size_t                                   scan_count = 0;
    status                           	      ans;
    memset(local_scan, 0, sizeof(local_scan));

    _waitScanData(local_buf, count); // // always discard the first data since it may be incomplete

    while(_isScanning)
    {
        if ((ans=_waitScanData(local_buf, count))) {
            if (ans != S_TIMEOUT) {
                _isScanning = false;
                return S_FAIL;
            }
        }

        for (size_t pos = 0; pos < count; ++pos)
        {
            if (local_buf[pos].sync == 1)
            {
                // only publish the data when it contains a full 360 degree scan

                if ((local_scan[0].sync == 1)) {
                    _lock.lock();
                    memcpy(_cached_scan_node_buf, local_scan, scan_count*sizeof(scanner_response_measurement_node_t));
                    _cached_scan_node_count = scan_count;
                    _dataEvt.set();
                    _lock.unlock();
                }
                scan_count = 0;
            }
            local_scan[scan_count++] = local_buf[pos];
            if (scan_count == _countof(local_scan)) scan_count-=1; // prevent overflow

        }
    }

    _isScanning = false;
    return S_OK;
}

status ScannerDriverSerial::_waitNode(scanner_response_measurement_node_t * node, uint32_t timeout)
{
    int  recvPos = 0;
    uint32_t startTs = getms();
    uint8_t  recvBuffer[sizeof(scanner_response_measurement_node_t)];
    uint8_t *nodeBuffer = (uint8_t*)node;
    uint32_t waitTime;

   while ((waitTime=getms() - startTs) <= timeout) {
        size_t remainSize = sizeof(scanner_response_measurement_node_t) - recvPos;
        size_t recvSize = sizeof(scanner_response_measurement_node_t);

        _my_serial->waitReadable();

        if (recvSize > remainSize) recvSize = remainSize;

        _my_serial->read(recvBuffer, recvSize);

        for (size_t pos = 0; pos < recvSize; ++pos) {
      	  uint8_t currentByte = recvBuffer[pos];
//			switch (recvPos) {
//			case 0: // expect the sync bit and its reverse in this byte
//				{
//				 uint8_t tmp = (currentByte>>1);
//					if ( (tmp ^ currentByte) & 0x1 ) {
//						// pass
//					} else {
//						continue;
//					}
//
//				}
//				break;
//			case 1: // expect the highest bit to be 1
//				{
//					if (currentByte & SCANNER_RESP_MEASUREMENT_CHECKBIT) {
//						// pass
//					} else {
//						recvPos = 0;
//						continue;
//					}
//				}
//				break;
//			}

            nodeBuffer[recvPos++] = currentByte;

            if (recvPos == sizeof(scanner_response_measurement_node_t) && nodeBuffer[7] == '\n') {
                return S_OK;
            }
        }
    }

   return S_FAIL;
}

status ScannerDriverSerial::_waitScanData(scanner_response_measurement_node_t * nodebuffer, size_t & count, uint32_t timeout)
{
    if (!_isConnected) {
        count = 0;
        return S_FAIL;
    }

    size_t   recvNodeCount =  0;
    uint32_t     startTs = getms();
    uint32_t     waitTime;

    while ((waitTime = getms() - startTs) <= timeout && recvNodeCount < count) {
        scanner_response_measurement_node_t node;
        if (_waitNode(&node, timeout - waitTime)) {
            return S_FAIL;
        }

        nodebuffer[recvNodeCount++] = node;

        if (recvNodeCount == count) return S_OK;
    }
    count = recvNodeCount;
    return S_FAIL;
}

status ScannerDriverSerial::grabScanData(scanner_response_measurement_node_t * nodebuffer, size_t & count, uint32_t timeout)
{
    switch (_dataEvt.wait(timeout))
    {
    case Event::EVENT_TIMEOUT:
        count = 0;
        return S_TIMEOUT;
    case Event::EVENT_OK:
        {
            if(_cached_scan_node_count == 0) return S_TIMEOUT; //consider as timeout

            AutoLocker l(_lock);

            size_t size_to_copy = min(count, _cached_scan_node_count);

            memcpy(nodebuffer, _cached_scan_node_buf, size_to_copy*sizeof(scanner_response_measurement_node_t));
            count = size_to_copy;
            _cached_scan_node_count = 0;
        }
        return S_OK;

    default:
        count = 0;
        return S_FAIL;
    }
}

status ScannerDriverSerial::getDeviceInfo(scanner_response_device_info_t &info, uint32_t timeout)
{
	if (!isConnected()) return S_FAIL;

	uint8_t cmd[] = {'I', 'V'};

	if(_sendCommand(cmd))
	{
		return S_FAIL;
	}

	scanner_ans_header_t response_header;
	if(_waitResponseHeader(&response_header, timeout))
	{
		return S_FAIL;
	}

	if(response_header.cmdByte1 != SCANNER_ANS_TYPE_DEVICE_INFO)
	{
		return S_FAIL;
	}

	uint8_t tempSum = ((response_header.cmdStatusByte1 + response_header.cmdStatusByte2) & 0x3F) + 0x30;


	if(response_header.cmdSum != tempSum)
	{
		return S_FAIL;
	}

	_my_serial->waitReadable();

   _my_serial->read(reinterpret_cast<uint8_t *>(&info), sizeof(info));

	return S_OK;
}

status ScannerDriverSerial::_sendCommand(uint8_t cmd[], const void * payload, size_t payloadsize)
{
	uint8_t pkt_header[10];
	scanner_cmd_packet_t * header = reinterpret_cast<scanner_cmd_packet_t * >(pkt_header);
	uint8_t checksum = 0;

	if(!_isConnected) return S_FAIL;

	header->cmdByte1 = cmd[0];
	header->cmdByte2 = cmd[1];
	header->cmdParamTerm = '\n';

	_my_serial->write(pkt_header, 3);

   return S_OK;
}

status ScannerDriverSerial::_waitResponseHeader(scanner_ans_header_t *header, uint32_t timeout)
{
	int recvPos = 0;
	uint32_t startTs = getms();
	uint8_t recvBuffer[sizeof(scanner_ans_header_t)];
	uint8_t *headerBuffer = reinterpret_cast<uint8_t *>(header);
	uint32_t waitTime;

	while((waitTime=getms() - startTs) <= timeout)
	{
		size_t remainSize = sizeof(scanner_ans_header_t) - recvPos;
		size_t recvSize;

		_my_serial->waitReadable();

		if(recvSize > remainSize) recvSize = remainSize;

		_my_serial->read(recvBuffer, recvSize);

      for (size_t pos = 0; pos < recvSize; ++pos) {
          uint8_t currentByte = recvBuffer[pos];
//          switch (recvPos) {
//          case 0:
//              if (currentByte != SCANNER_CMD_SYNC_BYTE) {
//                 continue;
//              }
//
//              break;
//          case 1:
//              if (currentByte != SCANNER_CMD_SYNC_BYTE) {
//                  recvPos = 0;
//                  continue;
//              }
//              break;
//          }
          headerBuffer[recvPos++] = currentByte;

          if (recvPos == sizeof(scanner_ans_header_t)) {
              return S_OK;
          }
      }
	}

	return S_FAIL;
}

status ScannerDriverSerial::_waitResponse(scanner_ans_complete_t *header, uint32_t timeout)
{
	int recvPos = 0;
	uint32_t startTs = getms();
	uint8_t recvBuffer[sizeof(scanner_ans_complete_t)];
	uint8_t *headerBuffer = reinterpret_cast<uint8_t *>(header);
	uint32_t waitTime;

	while((waitTime=getms() - startTs) <= timeout)
	{
		size_t remainSize = sizeof(scanner_ans_complete_t) - recvPos;
		size_t recvSize;

		_my_serial->waitReadable();

		if(recvSize > remainSize) recvSize = remainSize;

		_my_serial->read(recvBuffer, recvSize);

      for (size_t pos = 0; pos < recvSize; ++pos) {
          uint8_t currentByte = recvBuffer[pos];
//          switch (recvPos) {
//          case 0:
//              if (currentByte != SCANNER_CMD_SYNC_BYTE) {
//                 continue;
//              }
//
//              break;
//          case 1:
//              if (currentByte != SCANNER_CMD_SYNC_BYTE) {
//                  recvPos = 0;
//                  continue;
//              }
//              break;
//          }
          headerBuffer[recvPos++] = currentByte;

          if (recvPos == sizeof(scanner_ans_header_t)) {
              return S_OK;
          }
      }
	}

	return S_FAIL;
}

void ScannerDriverSerial::_disableDataGrabbing()
{
   _isScanning = false;
   _cachethread.join();
}
