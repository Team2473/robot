#include <string>
#include <iostream>
#include <cstdio>
#include "scanner.h"
#include "timer.h"
#include <unistd.h>

#ifndef _countof
#define _countof(_Array) (int)(sizeof(_Array) / sizeof(_Array[0]))
#endif

ScannerDriver * drv = NULL;

status     result;

int main(void) {

	drv = ScannerDriver::CreateDriver();
    float angle_f;
    uint16_t angle_i;

   if (!drv) {
       fprintf(stderr, "Create Driver fail, exit\n");
       return -2;
   }

   if(drv->connect("/dev/ttyUSB0", 115200))
   {
      fprintf(stderr, "Error, Serial Couldn't Connect\n");
      std::cout << "Could not connect" << std::endl;
      return -1;
   }

   if(drv->isConnected())
   {
   	std::cout << "Connected" << std::endl;
   }
   else
   {
   	std::cout << "Not Connected" << std::endl;
   }

   //scanner_response_device_info_t info;
   //drv->getDeviceInfo(info);

   drv->startScan();

   while(1)
   {
   	scanner_response_measurement_node_t nodes[360*2];
   	size_t count = _countof(nodes);

   	result = drv->grabScanData(nodes, count);
   	if(result == S_OK)
   	{
   		std::cout << "Full Scan Done" << std::endl;
   		for(int i = 0; i < count; i++)
   		{
   			std::cout << "node: " << i << std::endl;
   			std::cout << "distance: " << nodes[i].distance << std::endl;

            angle_i = nodes[i].angle;
            angle_f = 1.0f * ((float)(angle_i >> 4) + ((angle_i & 15) / 16.0f));
   			std::cout << "angle: " << angle_f << std::endl;
   		}
   	}
   	else if(result == S_FAIL)
   	{
   		std::cout << "Failure" << std::endl;
   	}
   	else if(result == S_TIMEOUT)
   	{
   		std::cout << "Timeout" << std::endl;
   	}

   	usleep(100000);
   }


	ScannerDriver::DestroyDriver(drv);

   std::cout << "end" << std::endl;
}

