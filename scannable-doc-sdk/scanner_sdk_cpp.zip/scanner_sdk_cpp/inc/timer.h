#pragma once

#include "stypes.h"

uint64_t getus();
uint32_t getms();

