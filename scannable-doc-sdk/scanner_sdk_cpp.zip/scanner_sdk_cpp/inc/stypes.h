#pragma once

#include <stdint.h>


typedef uint32_t status;

#define S_OK					0
#define S_FAIL					1
#define S_TIMEOUT				2
