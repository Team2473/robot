#pragma once

typedef struct _scanner_cmd_packet_t {
	uint8_t cmdByte1;
	uint8_t cmdByte2;
	uint8_t cmdParamTerm = 0x10;
} __attribute__((packed)) scanner_cmd_packet_t;

typedef struct _scanner_cmd_param_packet_t {
	uint8_t cmdByte1;
	uint8_t cmdByte2;
	uint8_t cmdParamByte1;
	uint8_t cmdParamByte2;
	uint8_t cmdParamTerm = 0x10;
} __attribute__((packed)) scanner_cmd_param_packet_t;

typedef struct _scanner_ans_header_t
{
	uint8_t cmdByte1;
	uint8_t cmdByte2;
	uint8_t	term1;
	uint8_t cmdStatusByte1;
	uint8_t cmdStatusByte2;
	uint8_t cmdSum;
	uint8_t	term2;

}__attribute__((packed)) scanner_ans_header_t;

typedef struct _scanner_ans_complete_t
{
	uint8_t cmdByte1;
	uint8_t cmdByte2;
	uint8_t cmdParamByte1;
	uint8_t cmdParamByte2;
	uint8_t cmdStatusByte1;
	uint8_t cmdStatusByte2;
	uint8_t cmdSum;

}__attribute__((packed)) scanner_ans_complete_t;
