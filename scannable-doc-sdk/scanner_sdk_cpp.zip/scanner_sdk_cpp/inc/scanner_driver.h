#pragma once



class ScannerDriver
{
public:
	enum
	{
		DEFAULT_TIMEOUT = 2000, //2000 ms
	};
public:

	static ScannerDriver * CreateDriver ();

	static void DestroyDriver (ScannerDriver * drv);

public:

	virtual status connect (const char* port, uint32_t baud, uint32_t timeout = DEFAULT_TIMEOUT) = 0;

	virtual void disconnect () = 0;

	virtual bool isConnected () = 0;

	virtual status stop() = 0;

	virtual status startScan(uint32_t timeout = DEFAULT_TIMEOUT) = 0;

	virtual status getDeviceInfo (scanner_response_device_info_t &info, uint32_t timeout = DEFAULT_TIMEOUT) = 0;

	virtual status grabScanData(scanner_response_measurement_node_t * nodebuffer, size_t & count, uint32_t timeout = DEFAULT_TIMEOUT) = 0;

protected:

	ScannerDriver ()
	{
	}
	virtual ~ScannerDriver ()
	{
	}
};
