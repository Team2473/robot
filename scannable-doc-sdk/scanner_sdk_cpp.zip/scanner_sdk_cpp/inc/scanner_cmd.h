#pragma once

#define SCANNER_CMD_STOP							0x05
#define SCANNER_CMD_START							0x15
#define SCANNER_CMD_RESET

#define SCANNER_CMD_GET_DEVICE_INFO				0x04
#define SCANNER_CMD_GET_DEVICE_HEALTH			0x06


#define SCANNER_ANS_TYPE_DEVICE_INFO			'I'
#define SCANNER_ANS_TYPE_MEASUREMENT			'S'

#define SCANNER_RESP_MEASUREMENT_SYNCBIT        (0x1<<0)

typedef struct _scanner_response_measurement_node_t
{
	uint8_t sync;
	uint16_t angle;
	uint16_t distance;
	uint8_t signal_strength;
	uint8_t error;
	uint8_t term;
}__attribute__((packed)) scanner_response_measurement_node_t;

typedef struct _scanner_response_device_info_t
{
	uint64_t vendor;
	uint64_t product;
	uint64_t firmware;
	uint64_t protocol;
	uint64_t serial;
}__attribute__((packed)) scanner_response_device_info_t;

typedef struct _scanner_response_device_health_t
{
	uint8_t status;
	uint16_t error_code;
}__attribute__((packed)) scanner_response_device_health_t;
