#pragma once

#include "serial/serial.h"

class ScannerDriverSerial : public ScannerDriver
{
public:
   enum {
       MAX_SCAN_NODES = 2048,
   };

	ScannerDriverSerial();
	virtual ~ScannerDriverSerial();

public:
	virtual status connect(const char* port, uint32_t baud, uint32_t timeout);
	virtual void disconnect();
	virtual bool isConnected();
	virtual status getDeviceInfo(scanner_response_device_info_t &info, uint32_t timeout);
	virtual status stop();
	virtual status startScan(uint32_t timeout);
	virtual status grabScanData(scanner_response_measurement_node_t * nodebuffer, size_t & count, uint32_t timeout = DEFAULT_TIMEOUT);

protected:
	status _sendCommand(uint8_t cmd[], const void * payload = NULL, size_t payloadsize = 0);
	status _waitResponse(scanner_ans_complete_t *header, uint32_t timeout);
	status _waitResponseHeader(scanner_ans_header_t *header, uint32_t timeout);
	void _disableDataGrabbing();
	status _cacheScanData();
	status _waitScanData(scanner_response_measurement_node_t * nodebuffer, size_t & count, uint32_t timeout = DEFAULT_TIMEOUT);
	status _waitNode(scanner_response_measurement_node_t * node, uint32_t timeout = DEFAULT_TIMEOUT);

	bool _isConnected;
	bool _isScanning;

	Thread _cachethread;
	serial::Serial * _my_serial;
	Locker         _lock;
	Event          _dataEvt;
	scanner_response_measurement_node_t      _cached_scan_node_buf[1024];
	size_t                                   _cached_scan_node_count;
};
